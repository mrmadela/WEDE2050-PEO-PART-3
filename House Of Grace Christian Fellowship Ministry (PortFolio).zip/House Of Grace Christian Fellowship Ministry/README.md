# **#PART 1**
ALL PAGE CONTAIN HTML AND INLINE CSS
    ### * HTML structure:
        <!DOCTYPE html>
        <html>
            <head>
                <title></title>
            </head>
            <body>
                <header>
                    <nav></nav>
                </header>
                <main>
                </main>
                <footer>
                </footer>
            </body>
        </html>

PAGES IN THE WEBSITE:
    1. Home page
    2. About us page
    3. Services page
    4. Donate page
    5. Events page
    6. Contact us page

                        ======================================= // =======================================

# **PART 2** (Cascading Styling Sheet)
## UPDATES AND IMPROVEMENCES

    1. Removed all inline css and internal css from all pages to extrnal css
    2. Added organasation name in the logo
    3. Changed color of the footer to darker color

    4. HOME PAGE:
        * Replaced/changed backgroung image for the previous had less resolutions and small damisions 
        * added button tags to the main for about us link and plan your visit

    5. ABOUT US PAGE:
        * not much has changed or improved except the backgreoung color of main (our vision. our mission, and meet our pages) and styling the page with extenal css.

    6. SERVICE PAGE:
        * Removed / Deleted the images under main on sunday services and weekdays prayer because there were unneccesary or didn't work well with the page
        * Styling the page using css

    7. DONATE PAGE:
        * Stlyling the page with external css

    8. EVENTS PAGE:
        * Removed event 1 from the website because the event has taken place
        * Style the page with css

    9. CONTACT US PAGE:
        * Styling the page with css to make look nice and professional


                        ======================================= // =======================================
#REFERENCING

1. W3Schools. (2025) HTML Tutorial. Available at: https://www.w3schools.com/html/
 (Accessed: 26 September 2025).

2. OpenAI. (2025) ChatGPT [AI language model]. Available at: https://chat.openai.com/
 (Accessed: 26 September 2025).

3. GitHub. (2025) GitHub Copilot [AI code assistant]. Available at: https://github.com/features/copilot
 (Accessed: 26 September 2025).

4. Google. (2025) Google Search Engine. Available at: https://www.google.com/
 (Accessed: 26 September 2025)
