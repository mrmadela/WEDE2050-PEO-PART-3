// ==============================
// HAMBURGER MENU (SAFE CREATION)
// ==============================
document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.querySelector('.navbar');

    if (navbar) {
        const hamburger = document.createElement('div');
        hamburger.classList.add('hamburger');
        hamburger.innerHTML = '&#9776;';
        navbar.prepend(hamburger);

        const navLinks = document.querySelector('.nav-links');

        hamburger.addEventListener('click', () => {
            navLinks?.classList.toggle('show');
            hamburger.classList.toggle('open');
        });
    }
});

// ==============================
// FOOTER DATE + LIVE CLOCK
// ==============================
function updateFooterTime() {
    const footerTime = document.querySelector('.footer_time');
    if (!footerTime) return;

    const now = new Date();
    footerTime.textContent = now.toLocaleString('en-ZA', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}
updateFooterTime();
setInterval(updateFooterTime, 1000);

// ==============================
// CONTACT FORM VALIDATION
// ==============================
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("contactForm");
    if (!form) return;

    const responseBox = document.getElementById("formResponse");
    const submitBtn = form.querySelector("button[type='submit']");

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        responseBox.innerHTML = "";
        let isValid = true;

        const fields = {
            fullName: document.getElementById("fullName"),
            email: document.getElementById("email"),
            phone: document.getElementById("phone"),
            subject: document.getElementById("subject"),
            message: document.getElementById("message"),
        };

        document.querySelectorAll(".error_message").forEach(msg => {
            msg.style.visibility = "hidden";
            msg.innerText = "";
        });

        Object.values(fields).forEach(f => f.removeAttribute("aria-invalid"));

        // VALIDATION
        if (fields.fullName.value.trim() === "") {
            showError(fields.fullName, "Full name is required.");
            isValid = false;
        }
        if (fields.email.value.trim() === "" || !validateEmail(fields.email.value)) {
            showError(fields.email, "Enter a valid email address.");
            isValid = false;
        }
        if (fields.phone.value.trim() !== "" && !/^\+?\d{7,15}$/.test(fields.phone.value.trim())) {
            showError(fields.phone, "Enter a valid phone number.");
            isValid = false;
        }
        if (fields.subject.value.trim() === "") {
            showError(fields.subject, "Subject is required.");
            isValid = false;
        }
        if (fields.message.value.trim().length < 10) {
            showError(fields.message, "Message must be at least 10 characters.");
            isValid = false;
        }

        if (!isValid) return;

        // SUCCESS
        responseBox.style.color = "green";
        responseBox.innerHTML = "Sending message...";
        submitBtn.disabled = true;

        setTimeout(() => {
            responseBox.innerHTML =
                "Your enquiry has been submitted successfully! We will contact you soon.";
            form.reset();
            submitBtn.disabled = false;
        }, 1500);
    });

    function showError(input, message) {
        const error = input.parentElement.querySelector(".error_message");
        if (error) {
            error.innerText = message;
            error.style.visibility = "visible";
        }
        input.setAttribute("aria-invalid", "true");
    }

    function validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
});

